package org.mockito.release.notes.util;

public class ReleaseNotesException extends RuntimeException {

    public ReleaseNotesException(String message, Throwable cause) {
        super(message, cause);
    }
}
